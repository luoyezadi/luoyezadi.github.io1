title: 使用Git开发时常用操作
author: LZH
tags:
  - Git
categories: []
date: 2019-04-20 18:55:00
---
Coding帮助文档[https://coding.net/help/doc/practice](https://coding.net/help/doc/practice)
[https://e.coding.net/help/doc/start/](https://e.coding.net/help/doc/start/)
不清楚以上两个是不是都是真的，不过上面的那个更好点

1.创建
2.添加缓存区
3.提交
4.创建分支
5.合并分支
6.pull
7.push
8.发生冲突怎么处理
[https://coding.net/help/doc/practice/git-workflow.html](https://coding.net/help/doc/practice/git-workflow.html)
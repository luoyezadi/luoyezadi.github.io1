title: Oracle中常用函数
author: LZH
tags:
  - Oracle
  - 函数
categories: []
date: 2019-04-20 19:18:00
---
substring
nvl

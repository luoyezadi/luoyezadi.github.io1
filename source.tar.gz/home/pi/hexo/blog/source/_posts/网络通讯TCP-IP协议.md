title: 网络通讯TCP/IP协议
author: LZH
tags:
  - TCP/IP
categories: []
date: 2019-04-20 19:10:00
---
几次握手啥的
还有就是路由
iso8层结构
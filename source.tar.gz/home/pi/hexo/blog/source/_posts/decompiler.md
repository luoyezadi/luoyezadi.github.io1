title: 很好用的Eclipse插件
author: LZH
tags:
  - decompiler
  - java
  - 反编译
categories: []
date: 2019-05-08 17:16:00
---
# 1.decompiler
查看源码用的
# 2.Bytecode Outline
[https://blog.csdn.net/linbilin_/article/details/60959461](https://blog.csdn.net/linbilin_/article/details/60959461)
Eclipse安装查看java字节码插件
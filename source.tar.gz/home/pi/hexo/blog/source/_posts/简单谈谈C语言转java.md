title: 简单谈谈C语言转java
author: LZH
tags:
  - C
  - java
categories: []
date: 2019-04-20 19:02:00
---
两个语言其实有很多基础操作类似的方法和数据类型


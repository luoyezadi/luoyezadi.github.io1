title: AngularJs简单使用记录
author: LZH
tags:
  - AngularJs
categories: []
date: 2019-04-20 19:04:00
---
AngularJs
中$scop很重要相当于一个域？
$watch
$http
$销毁

title: WebSSH2安装教程
author: LZH
tags:
  - WebSSH2
categories: []
date: 2019-04-23 02:48:00
---
参照:[https://blog.csdn.net/weixin_34393428/article/details/87057656](https://blog.csdn.net/weixin_34393428/article/details/87057656)
缺少package.json:npm init[https://blog.csdn.net/u011240877/article/details/76582670](https://blog.csdn.net/u011240877/article/details/76582670)

github源码[https://github.com/billchurch/WebSSH2](https://github.com/billchurch/WebSSH2)

# 以下所有npm全部尽量使用cnpm（淘宝源）
# 1.安装git npm Node.js
# 2.clon
## 缺少package.json的话:npm init
```
git clone https://github.com/billchurch/WebSSH2
cd WebSSH2
npm install --production
```
npm install --production 有错的话用下面替换
```
npm install --production
```
# 3.开一个远程画面
```
cd WebSSH2
npm start
```
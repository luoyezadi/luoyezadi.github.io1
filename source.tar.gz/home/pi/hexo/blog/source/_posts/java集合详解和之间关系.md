title: java集合详解和之间关系
author: LZH
tags:
  - java
  - 集合
categories: []
date: 2019-04-20 03:42:00
---
# 1.java集合家族史:

所有集合都继承于Collection接口：
collection犹如太极一般，一分为二，一者曰List，再者曰Set。
话说，太极生两仪，两仪生四象。以上二者，List再生ArrayList/Vecter/LinkedList，Set再生TreeSet/HashSet。（ps：总感觉去了Vecter才是完美的呀，强迫症一枚。。。）
Collection--List--ArrayList
      |    |--Vecter
      |    |--LinkedList
      |--Set--HashSet
         |--TreeSet
（以上由于自己服务器内存不打，再者图床网站不一定啥时候就图片加载不是出来了，因此没有用图片，见谅。。。）

title: java集合详解和之间关系
author: LZH
tags:
  - java
  - 集合
categories: []
date: 2019-04-20 03:42:00
---
# 1.java常用集合类家族史:

（具体请参照API[http://tool.oschina.net/apidocs/apidoc?api=jdk-zh](http://tool.oschina.net/apidocs/apidoc?api=jdk-zh)）
常用集合如太极一般，一分为二，一者曰Collection，再者曰Map。
话说，太极生两仪，两仪生四象。。。（布拉布拉。。。）
## Collection接口
其中Collection接口一般用到的就是List和Set两种（下面其他的也会涉及到不过以这两种为主）：
以上二者，List再生ArrayList/Vector/LinkedList，Set再生TreeSet/HashSet。
Collection--List--ArrayList
      |    |--Vecter
      |    |--LinkedList
      |--Set--HashSet
         |--TreeSet
（这几个用的多，但是辈分不一样，详看下图）

## Map接口（图）
Map接口最多的就是HashMap，其他的就是看看，平时一般用不到，除非很特殊的地方
![](集合框架体系1.jpg)
# 2.各自优点
![](集合框架体系3.png)
![](集合框架体系2.jpg)
## 接口
### 1.Collection 接口
Collection 是最基本的集合接口，一个 Collection 代表一组 Object，即 Collection 的元素, Java不提供直接继承自Collection的类，只提供继承于的子接口(如List和set)。
Collection 接口存储一组不唯一，无序的对象。
### 2.List 接口
List接口是一个有序的 Collection，使用此接口能够精确的控制每个元素插入的位置，能够通过索引(元素在List中位置，类似于数组的下标)来访问List中的元素，第一个元素的索引为 0，而且允许有相同的元素。
List 接口存储一组不唯一，有序（插入顺序）的对象。
### 3.Set 接口
Set 具有与 Collection 完全一样的接口，只是行为上不同，Set 不保存重复的元素。
Set 接口存储一组唯一，无序的对象。
### 4.SortedSet
继承于Set保存有序的集合。
### 5.Map
Map 接口存储一组键值对象，提供key（键）到value（值）的映射。
### 6.Map.Entry 
描述在一个Map中的一个元素（键/值对）。是一个Map的内部类。
### 7.SortedMap
继承于 Map，使 Key 保持在升序排列。

ps：对有序的理解
List有序和Set无序说的是啥呢？
就是呀，List是进去啥顺序，出来也是啥顺序。Set呢也想保证跟List一样的顺序的话是不行的，Set会自动去重（Set内心：就是不一样！能拿我怎么样！）。
这就有小伙伴说了，SortedSet不是也是有序的呀，这不是跟List一样啊！这么说就不对了，此有序非彼有序，SortedSet有序是因为他会自动排序！就是说，有序的概念有很多种比如正序倒序都是有序。

## 实现类

（太多了，列多点，其实看其中几个常用的就行了）






